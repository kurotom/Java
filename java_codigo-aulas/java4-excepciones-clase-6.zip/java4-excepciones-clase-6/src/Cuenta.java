
public class Cuenta {

	void deposita() throws MiException {
		
	}
	
}
